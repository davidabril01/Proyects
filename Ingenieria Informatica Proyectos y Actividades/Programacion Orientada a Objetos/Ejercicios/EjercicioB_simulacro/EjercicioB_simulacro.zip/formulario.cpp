#include "formulario.h"
#include "ui_formulario.h"
#include <iostream>

Formulario::Formulario(QWidget *parent)
  : QMainWindow(parent)
  , ui(new Ui::Formulario)
{
  ui->setupUi(this);

  connect(ui->pushButton_Agregar, SIGNAL(pressed()), this, SLOT(on_pushButton_Agregar_pressed()));
  connect(ui->pushButton_VerStock, SIGNAL(pressed()), this, SLOT(on_pushButton_VerStock_pressed()));
}

void Formulario::AgregarStock(Instrumento& inst) {
    Stock.append(&inst);
}

Formulario::~Formulario()
{
  for (Instrumento* inst : Stock) {
          delete inst;
      }
  delete ui;
}

void Formulario::on_pushButton_Agregar_pressed()
{
  QString selectedInstrument = ui->comboBox->currentText();
  if (selectedInstrument == "Guitarra") {
      Guitarra* guitarra = new Guitarra("MarcaGuitarra", 150.0, 6);
      AgregarStock(*guitarra);
   } else if (selectedInstrument == "Viento") {
      Viento* viento = new Viento("MarcaViento", 120.0, "Latón");
      AgregarStock(*viento);
   } else if (selectedInstrument == "Teclado") {
      Teclado* teclado = new Teclado("MarcaTeclado", 300.0, 88);
      AgregarStock(*teclado);
   } else {
      return;
    }
}

void Formulario::on_pushButton_VerStock_pressed() {
    for (Instrumento* inst : Stock) {
        if (dynamic_cast<Guitarra*>(inst)) {
            Guitarra* guitarra = dynamic_cast<Guitarra*>(inst);
            std::cout << "Guitarra - Marca: " << guitarra->getMarca().toStdString()
                      << ", Precio: " << guitarra->getPrecio()
                      << ", Cuerdas: " << guitarra->getCantidadDeCuerdas()
                      << std::endl;
        } else if (dynamic_cast<Viento*>(inst)) {
            Viento* viento = dynamic_cast<Viento*>(inst);
            std::cout << "Viento - Marca: " << viento->getMarca().toStdString()
                      << ", Precio: " << viento->getPrecio()
                      << ", Metal usado: " << viento->getMetalUsado().toStdString()
                      << std::endl;
        } else if (dynamic_cast<Teclado*>(inst)) {
            Teclado* teclado = dynamic_cast<Teclado*>(inst);
            std::cout << "Teclado - Marca: " << teclado->getMarca().toStdString()
                      << ", Precio: " << teclado->getPrecio()
                      << ", Teclas: " << teclado->getCantidadDeTeclas()
                      << std::endl;
        }
    }
}
