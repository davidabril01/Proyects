#include "teclado.h"
#include <iostream>
using namespace std;

Teclado::Teclado(const QString& marca, double precio, int cantidad_de_teclas)
    : Instrumento(marca, precio), cantidad_de_teclas(cantidad_de_teclas) {}

void Teclado::afinar() {
    cout << "Afinando teclado" << endl;
}

int Teclado::getCantidadDeTeclas() const {
    return cantidad_de_teclas;
}
