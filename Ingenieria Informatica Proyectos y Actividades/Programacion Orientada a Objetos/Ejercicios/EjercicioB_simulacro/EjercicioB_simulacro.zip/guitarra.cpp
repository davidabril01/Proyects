#include "guitarra.h"
#include <iostream>
using namespace std;

Guitarra::Guitarra(const QString& marca, double precio, int cantidad_de_cuerdas)
    : Instrumento(marca, precio), cantidad_de_cuerdas(cantidad_de_cuerdas) {}

void Guitarra::afinar(){
    cout << "Afinando guitarra" << endl;
}

int Guitarra::getCantidadDeCuerdas() const {
    return cantidad_de_cuerdas;
}
