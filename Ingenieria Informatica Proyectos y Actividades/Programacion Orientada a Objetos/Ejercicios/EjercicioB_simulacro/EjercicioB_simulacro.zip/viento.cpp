#include "viento.h"
#include <iostream>
using namespace std;

Viento::Viento(const QString& marca, double precio, const QString& metal_usado)
    : Instrumento(marca, precio), metal_usado(metal_usado) {}

void Viento::afinar() {
    cout << "Afinando instrumento de viento" << endl;
}

QString Viento::getMetalUsado() const {
    return metal_usado;
}
