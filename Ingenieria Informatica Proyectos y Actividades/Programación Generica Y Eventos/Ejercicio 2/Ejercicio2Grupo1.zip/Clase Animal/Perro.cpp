#include "Perro.h"
#include <iostream>

using namespace std;

Perro::Perro() {
}

Perro::~Perro() {
}

void Perro::Ladrar() {
    cout << "El perro está ladrando: guau guau" << endl;
}
