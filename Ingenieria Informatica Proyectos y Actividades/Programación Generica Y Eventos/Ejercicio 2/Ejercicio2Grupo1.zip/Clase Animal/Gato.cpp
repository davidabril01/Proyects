#include "Gato.h"
#include <iostream>

using namespace std;

Gato::Gato() {
}

Gato::~Gato() {
}

void Gato::Maullar() {
    cout << "El gato está maullando: miau miau" << endl;
}
