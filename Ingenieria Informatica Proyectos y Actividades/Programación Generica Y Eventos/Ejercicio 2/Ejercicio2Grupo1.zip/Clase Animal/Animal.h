#ifndef ANIMAL_H
#define ANIMAL_H

class Animal {
private:
public:
    Animal();
    ~Animal();

    void Comer();
    void Dormir();
};

#endif // ANIMAL_H
