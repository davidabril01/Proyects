#include <iostream>
#include "Inventario.h"

using namespace std;

int main()
{

    Inventario inventario;
    inventario.RunEventLoop();
    return 0;
}
